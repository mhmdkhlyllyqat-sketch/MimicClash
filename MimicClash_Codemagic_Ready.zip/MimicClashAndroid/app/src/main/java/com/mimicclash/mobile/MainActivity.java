package com.mimicclash.mobile;

import android.Manifest;import android.app.Activity;import android.os.Bundle;import android.content.pm.PackageManager;import android.media.MediaPlayer;import android.media.MediaRecorder;import android.view.View;import android.widget.*;import java.io.*;import java.util.*;

public class MainActivity extends Activity {
  MediaPlayer player; MediaRecorder recorder; File recFile; Random rng=new Random(); TextView status,score; int points=0;
  ArrayList<String> sounds=new ArrayList<>();
  public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); status=findViewById(R.id.status);score=findViewById(R.id.score);
    try{for(String n:getAssets().list("sounds")) if(n.endsWith(".mp3")) sounds.add(n);}catch(Exception e){}
    ((TextView)findViewById(R.id.info)).setText(sounds.size()+" Meme Sounds");
    findViewById(R.id.play).setOnClickListener(v->playRandom());
    findViewById(R.id.record).setOnClickListener(v->toggleRecord());
    if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10);
  }
  void playRandom(){try{if(player!=null)player.release();String n=sounds.get(rng.nextInt(sounds.size()));player=new MediaPlayer();player.setDataSource(getAssets().openFd("sounds/"+n).getFileDescriptor(),getAssets().openFd("sounds/"+n).getStartOffset(),getAssets().openFd("sounds/"+n).getLength());player.prepare();player.start();status.setText("🎵 استمع ثم قلّد الصوت");}catch(Exception e){status.setText("تعذر تشغيل الصوت");}}
  void toggleRecord(){try{if(recorder==null){recFile=new File(getCacheDir(),"attempt.3gp");recorder=new MediaRecorder();recorder.setAudioSource(MediaRecorder.AudioSource.MIC);recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);recorder.setOutputFile(recFile);recorder.prepare();recorder.start();status.setText("🔴 التسجيل جارٍ... اضغط مرة أخرى للإيقاف");((Button)findViewById(R.id.record)).setText("⏹️ إيقاف التسجيل");}else{recorder.stop();recorder.release();recorder=null;points+=10;score.setText("النقاط: "+points);status.setText("تم التسجيل! +10 نقاط (نسخة أولية)");((Button)findViewById(R.id.record)).setText("🎙️ ابدأ تقليد الصوت");}}catch(Exception e){status.setText("تعذر التسجيل");recorder=null;}}
  protected void onDestroy(){if(player!=null)player.release();if(recorder!=null){try{recorder.release();}catch(Exception e){}}super.onDestroy();}
}
