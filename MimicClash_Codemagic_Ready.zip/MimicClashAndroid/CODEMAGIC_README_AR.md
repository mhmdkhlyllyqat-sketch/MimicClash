# Mimic Clash — إعداد Codemagic

هذا المشروع مجهز للبناء السحابي على Codemagic.

## البناء

1. ارفع مجلد المشروع إلى مستودع Git.
2. أضف المشروع في Codemagic.
3. اختر ملف `codemagic.yaml` الموجود في جذر المشروع.
4. شغّل workflow باسم **Mimic Clash Android APK**.
5. بعد نجاح البناء ستجد ملف APK ضمن Artifacts.

هذا الإعداد يبني نسخة **Debug APK** للتجربة على الهاتف، ولا يحتاج إلى إعداد مفتاح نشر Google Play.
